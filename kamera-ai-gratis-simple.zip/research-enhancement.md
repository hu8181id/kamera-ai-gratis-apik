# Temuan Enhancement On-Device dan HDR

Expo Camera menyediakan `CameraView` untuk foto/video, pengaturan zoom, flash, mode picture/video, dan penyimpanan hasil ke cache perangkat. Dokumentasi resminya tidak menyediakan API umum untuk manipulasi brightness, sharpening, atau penggabungan HDR multi-frame di JavaScript. Sumber: https://docs.expo.dev/versions/latest/sdk/camera/

Android Camera2 menyediakan capture session, `captureBurst`, dan reprocessable capture session untuk menangkap beberapa exposure dan memproses ulang hasil pada pipeline native. Ini merupakan jalur yang tepat untuk HDR multi-frame, tetapi tidak tersedia langsung melalui Expo Camera standar. Sumber: https://developer.android.com/reference/android/hardware/camera2/CameraCaptureSession

Model enhancement/super-resolution benar-benar dapat dijalankan on-device menggunakan model teroptimasi seperti TensorFlow Lite, tetapi memerlukan model binary, native bridge atau runtime yang kompatibel, serta pengujian performa dan memori pada perangkat. Sumber: https://blog.tensorflow.org/2020/12/how-to-build-a-super-resolution-model-for-mobile-devices.html

Keputusan implementasi: versi Expo saat ini akan menambahkan kontrol intensitas dan preset yang mengatur parameter capture serta pipeline lokal; HDR multi-frame akan memiliki fallback ke satu frame. Untuk enhancement AI visual yang benar-benar kuat, proyek memerlukan modul native Android/Camera2 dan model on-device yang dibundel, bukan kredit Manus atau API cloud.


## Riset jalur native lanjutan

Dokumentasi Android menyarankan CameraX untuk kebutuhan umum, sedangkan Camera2 cocok untuk fitur tingkat rendah. Camera2 mendukung beberapa output stream, pengaturan exposure pada capture request, dan pipeline still-capture/video yang dapat dioptimalkan oleh perangkat. Sumber: https://developer.android.com/media/camera/camera2/capture-sessions-requests

LiteRT adalah runtime Google untuk machine learning on-device dengan opsi model `.tflite`, optimasi/quantization, serta akselerasi CPU/GPU/NPU. Sumber: https://developers.google.com/edge/litert

Expo Go hanya dapat menggunakan library native yang sudah termasuk dalam Expo SDK. Custom Camera2 module dan runtime model memerlukan development build, local Expo module, serta native Android code. Sumber: https://docs.expo.dev/workflow/customizing/ dan https://docs.expo.dev/modules/native-module-tutorial/

Keputusan teknis: fondasi yang aman untuk proyek ini adalah menambahkan kontrak bridge `NativeCameraEnhancer` dengan fallback Expo. Implementasi Camera2/LiteRT produksi perlu development build Android; Expo Go tetap menjalankan fallback yang telah ada.


## Kandidat model LiteRT

Kandidat yang paling terdokumentasi adalah ESRGAN dari TensorFlow Hub untuk super-resolution. Tutorial resmi menunjukkan model sekitar 20,60 MB sebelum konversi, input dapat difiksasi 50x50, dan model dapat dikonversi ke LiteRT/TFLite dengan dynamic-range quantization. Sumber: https://www.tensorflow.org/hub/tutorials/image_enhancing dan https://blog.tensorflow.org/2020/12/how-to-generate-super-resolution-images-using-tensorflow-lite-on-android.html

Kode tutorial Google menggunakan lisensi Apache 2.0, tetapi bobot model pihak ketiga di TF Hub harus diverifikasi sesuai halaman model sebelum didistribusikan. Karena ESRGAN dapat berat untuk perangkat low-end, model ini cocok sebagai preset flagship atau mode kualitas tinggi, bukan default universal.

Repository resmi Google AI Edge LiteRT Samples berlisensi Apache 2.0 dan menyediakan contoh deployment, konversi, quantization, serta verifikasi on-device. Sumber: https://github.com/google-ai-edge/litert-samples

Keputusan sementara: jangan mengunduh atau membundel bobot ESRGAN sebelum verifikasi lisensi bobot dan ukuran APK. Untuk prototipe aman, pertahankan native brightness/contrast dan HDR frame merge sebagai baseline; LiteRT harus masuk setelah model yang disetujui dipilih dan diuji pada perangkat target.
