# Matriks Pengujian Perangkat Android

| Profil | Contoh kemampuan | Yang diuji | Hasil yang diharapkan |
|---|---|---|---|
| Low-end | Android 10–12, RAM 3–4 GB, tanpa ultrawide | Foto Auto/Malam, enhancement level Natural, video 480p | Tidak crash, waktu proses masih dapat diterima, fallback Expo aktif |
| Mid-range | Android 12–14, RAM 6–8 GB, ultrawide tersedia | Foto 0.5x/1x, HDR tiga frame, video 720p/1080p | Lensa tersedia dipilih benar, HDR fallback aman, video stabil sesuai hardware |
| Flagship | Android 13–16, RAM 8 GB+, Camera2 tingkat tinggi | HDR native merge, enhancement LiteRT CPU/GPU/NPU, video 1080p | Native engine aktif, hasil terang/tajam, waktu proses dan suhu terukur |
| Tanpa ultrawide | Camera2 hanya satu kamera belakang | Tombol 0.5x dan 1x | 0.5x menggunakan fallback terendah tanpa crash |
| Dengan ultrawide | Camera2 memiliki kamera ultra-wide | Foto/video 0.5x | Preview dan hasil memakai kamera ultrawide bila didukung API perangkat |

## Status Saat Ini

Pemeriksaan statis `pnpm check` dan `pnpm lint` berhasil. Preview web menggunakan fallback karena browser tidak memiliki kamera native Expo. Bridge `ExpoCameraEnhancer` sudah disiapkan secara opsional; status `AI native` baru akan aktif setelah custom development build Android yang berisi Camera2 dan LiteRT. Expo Go tetap menggunakan fallback lokal.

## Prosedur uji fisik

Jalankan aplikasi melalui Expo Go untuk fallback, kemudian melalui development build Android untuk native bridge. Pada setiap profil, ambil foto Auto, Malam, dan HDR; catat waktu dari rana hingga tersimpan, ukuran file, kualitas visual, suhu perangkat, dan apakah aplikasi menampilkan error. Rekam video pada 480p, 720p, dan 1080p sambil berjalan, lalu periksa stabilisasi dan audio.


## Mode AI

| Mode | Strategi | Target perangkat |
|---|---|---|
| Cepat | Enhancement native ringan dengan latency terendah; LiteRT tetap dapat fallback bila gagal | Low-end atau kondisi perlu cepat |
| Seimbang | Brightness/contrast native dengan kualitas JPEG tinggi dan inference lokal bila tersedia | Mid-range sebagai default |
| Detail Tinggi | Menjalankan jalur ESRGAN LiteRT bila development build tersedia; paling lambat dan paling berat | Flagship atau foto penting |

## Development build Android

Setelah perubahan native, jalankan `npx expo prebuild --platform android --no-install`, lalu gunakan Android Studio atau `npx expo run:android` pada perangkat/emulator yang tersedia. Expo Go tidak memuat local native module, sehingga status AI native dan ESRGAN hanya dapat diverifikasi pada development build. Untuk pengujian yang dapat dibandingkan, gunakan objek dan pencahayaan yang sama, tiga tingkat preset, serta catat latency rana-ke-simpan, suhu sebelum/sesudah, penggunaan memori, ukuran file, dan hasil visual.

## Batasan validasi saat ini

Sandbox telah memvalidasi TypeScript, lint, bundling web, serta fallback web. Hasil latency, suhu, Camera2 burst, HDR native, ultrawide, dan stabilisasi belum dapat diisi sebagai hasil aktual sebelum perangkat Android fisik tersambung.


## Format log runtime

Saat foto atau video selesai disimpan, aplikasi menulis event `[camera-metrics]` yang memuat `mediaType`, `preset`, `aiProfile`, `engine`, `processingMs`, dan `fileSizeBytes`. Nilai memori dan suhu diberi penanda `record-on-device` karena harus dicatat dari perangkat Android melalui Android Studio atau aplikasi pemantau sistem. Salin satu event untuk setiap mode AI dan profil perangkat ke tabel pengujian sebelum membandingkan hasil.
