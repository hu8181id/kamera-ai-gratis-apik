# Project TODO

- [x] Kamera portrait dengan pratinjau dan tombol rana
- [x] Mode Foto dan Video
- [x] Kontrol lensa 0.5x ultrawide dan 1x utama bila didukung perangkat
- [x] Kontrol exposure/terang yang dapat diatur pengguna
- [x] Preset peningkatan foto terang dan tajam secara lokal
- [x] Stabilisasi video melalui kemampuan kamera perangkat
- [x] Penyimpanan media lokal dan pratinjau hasil
- [x] Galeri lokal sederhana
- [x] Pengaturan kamera dan bantuan penggunaan
- [x] Logo aplikasi dan konfigurasi branding
- [x] Pengujian TypeScript, lint, serta unit test deterministik
- [x] Dokumentasi batasan perangkat dan cara menjalankan aplikasi

- [x] Proses foto otomatis secara lokal: terang dan tajam sebelum penyimpanan
- [x] Simpan otomatis foto/video ke galeri perangkat dan tampilkan pratinjau hasil
- [x] Galeri lokal dengan hapus dan bagikan
- [x] Preset Malam/HDR dan pilihan kualitas video

- [x] Enhancement on-device yang lebih kuat tanpa API cloud atau kredit Manus
- [x] Slider intensitas enhancement untuk mengatur terang dan ketajaman
- [x] HDR multi-frame lokal dengan fallback bila perangkat tidak mendukung
- [x] Pengujian pada beberapa profil perangkat Android dan dokumentasi kompatibilitas

- [ ] Integrasi native Android Camera2 untuk capture burst dan merge HDR
- [ ] Integrasi model AI on-device untuk enhancement terang dan tajam tanpa cloud
- [x] Fallback aman ke pipeline Expo bila native module/model tidak tersedia
- [x] Matriks pengujian Android low-end, mid-range, flagship, ultrawide, dan non-ultrawide

- [x] Pilih model enhancement LiteRT yang berlisensi jelas dan sesuai ukuran APK
- [x] Bundel model LiteRT dan hubungkan inference ke native module Android
- [ ] Siapkan development build Android untuk Camera2 dan modul native
- [ ] Uji waktu proses, suhu, HDR, ultrawide, dan stabilisasi pada beberapa perangkat

- [x] Konfigurasi dan dokumentasi development build Android yang dapat menjalankan modul native
- [x] Tambahkan mode AI Cepat, Seimbang, dan Detail Tinggi pada alur foto
- [x] Buat prosedur pengujian latency, suhu, memori, HDR, ultrawide, dan stabilisasi per kelas perangkat
- [ ] Catat hasil pengujian aktual setelah perangkat Android tersedia

- [x] Tambahkan panduan development build Android dan checklist instalasi pada perangkat
- [x] Tambahkan logging latency, ukuran file, memori, dan status engine per mode AI
- [x] Tambahkan prosedur pencatatan suhu perangkat secara manual selama uji
- [x] Perkuat Camera2 burst HDR native dan fallback aman ke merge lokal Expo

- [ ] Jalankan atau validasi development build Android jika perangkat/toolchain tersedia
- [x] Tambahkan ringkasan metrik performa yang mudah diekspor untuk tiga mode AI
- [x] Tingkatkan burst HDR native dan fallback ketika Camera2 atau native module tidak tersedia
- [ ] Dokumentasikan hasil validasi aktual dan keterbatasan sandbox tanpa perangkat fisik

- [x] Pastikan konfigurasi proyek siap untuk APK Android native
- [x] Validasi aset ikon, permission kamera/mikrofon/galeri, dan fallback native
- [x] Simpan checkpoint siap Publish dan tulis langkah pemasangan APK di HP Android

- [x] Hapus konflik secret proyek dengan nama terlarang EXPO_TOKEN
- [x] Validasi build tanpa mendeklarasikan EXPO_TOKEN sebagai secret aplikasi
- [x] Dokumentasikan bahwa token build dimasukkan melalui kartu Setup access token from Expo
- [x] Sederhanakan alur build APK melalui satu ZIP dan satu workflow GitHub Actions tanpa unggah folder satu per satu.
- [x] Perbaiki kegagalan workflow karena ZIP yang diunggah berasal dari repository terflatten dan tidak berisi package.json.
- [ ] Unggah ZIP source berstruktur benar ke root GitHub dan jalankan ulang workflow build APK.
- [ ] Diagnosis dan perbaiki kegagalan merah terbaru pada GitHub Actions.
- [ ] Buat repository GitHub baru yang bersih dan gunakan ZIP source valid untuk build APK.
- [x] Diagnosis kegagalan build terbaru setelah proses Gradle berjalan 7 menit.
- [ ] Unggah ulang ZIP setelah memperbaiki file Kotlin native yang salah.
- [ ] Buat versi build sederhana tanpa modul Kotlin native/ESRGAN yang menyebabkan Gradle gagal.
