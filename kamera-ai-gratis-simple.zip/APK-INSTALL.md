# Panduan APK Android

Proyek ini sudah disiapkan untuk dibuat sebagai APK melalui panel **Publish** pada antarmuka proyek. Buka checkpoint terbaru, tekan **Publish**, lalu tunggu proses build Android selesai. Unduh APK yang dihasilkan ke HP Android, buka file tersebut, izinkan pemasangan dari sumber yang dipilih bila Android memintanya, lalu pasang.

Setelah aplikasi terbuka, izinkan kamera, mikrofon, dan galeri. Uji mode Cepat, Seimbang, dan Detail Tinggi secara berurutan. Mode AI native Camera2/LiteRT hanya aktif pada build native yang memuat modul tersebut; bila modul tidak tersedia, aplikasi memakai fallback lokal Expo sehingga foto tetap dapat diproses dan disimpan.

Penting: sandbox pengembangan ini tidak memiliki Android SDK, `adb`, atau HP fisik yang terhubung. Oleh karena itu, APK tidak dapat dipasang otomatis dari sini dan hasil suhu, latency, HDR burst, ultrawide, serta stabilisasi harus diverifikasi setelah APK dipasang pada perangkat Android.

## Token Expo untuk Build

Saat panel build menampilkan **Setup access token from Expo**, masukkan token pada kartu tersebut lalu mulai build. Jangan menambahkan `EXPO_TOKEN` melalui Secrets proyek karena nama itu dicadangkan oleh sistem build dan menyebabkan error `invalid_argument`.
