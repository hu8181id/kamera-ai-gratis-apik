/** @type {const} */
const themeColors = {
  primary: { light: '#F4B942', dark: '#F4B942' },
  background: { light: '#070A0D', dark: '#070A0D' },
  surface: { light: '#151A20', dark: '#151A20' },
  foreground: { light: '#F8FAFC', dark: '#F8FAFC' },
  muted: { light: '#A8B3BF', dark: '#A8B3BF' },
  border: { light: '#26313B', dark: '#26313B' },
  success: { light: '#49D17D', dark: '#49D17D' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
