# Native Android Camera Enhancement

Proyek sekarang memiliki local Expo module `modules/expo-camera-enhancer` untuk development build Android. Modul tersebut menyediakan bridge `ExpoCameraEnhancer` dengan dua fungsi: `enhancePhoto(uri, intensity)` untuk peningkatan brightness/contrast lokal dan `mergeHdrFrames(uris)` untuk penggabungan frame sederhana secara lokal.

Implementasi ini **bukan model LiteRT/AI neural network**. Ia adalah fondasi native yang bebas cloud dan bebas kredit Manus. Model LiteRT perlu ditambahkan sebagai dependency dan file model `.tflite` yang telah di-quantize; file model belum dibundel karena pilihan model, ukuran APK, lisensi, dan target akselerator belum ditentukan.

Expo Go tidak memuat custom native module. Untuk mengaktifkan modul, gunakan development build Android setelah menjalankan prebuild/build sesuai panduan Expo. Tanpa development build, aplikasi otomatis menggunakan pipeline Expo fallback dan tetap dapat mengambil, meningkatkan, serta menyimpan foto.

Pemeriksaan `pnpm check` dan `pnpm lint` berhasil setelah scaffold native diperbaiki. Pengujian fisik HDR, waktu inference, temperatur, dan akselerasi GPU/NPU masih harus dilakukan pada perangkat Android nyata.


## Model enhancement yang dipilih

Model `captain-pool/lite-model/esrgan-tf2/1` dipilih sebagai mode enhancement kualitas tinggi. Halaman model mencantumkan format LiteRT/TFLite, lisensi MIT, dan ukuran file sekitar 4,99 MB. Model menerima input 50×50 RGB dan menghasilkan super-resolution 4×; karena itu implementasi native menjalankannya sebagai enhancement setelah brightness/contrast dan menyimpan hasil JPEG lokal.

Model ini tidak dipakai oleh Expo Go. Ia hanya aktif apabila custom native module berhasil dimuat pada development build Android. Jika inference gagal karena memori, akselerator, format URI, atau kompatibilitas perangkat, modul kembali ke enhancement native brightness/contrast. Pengujian suhu, latency, burst Camera2, dan stabilisasi harus dilakukan pada perangkat nyata; sandbox hanya memvalidasi TypeScript/lint dan fallback web.


## HDR native saat ini

Bridge native sekarang melakukan merge berbobot luminance pada dua atau lebih URI frame yang diberikan aplikasi. Bobot lebih tinggi diberikan pada piksel midtone agar highlight yang terlalu terang dan area gelap tidak mendominasi rata-rata sederhana. Ini meningkatkan baseline HDR lokal, tetapi belum sama dengan `Camera2` capture burst dengan exposure bracket pada sensor; capture frame masih berasal dari Expo Camera. Jika native merge gagal, aplikasi memakai frame pertama sebagai fallback.
