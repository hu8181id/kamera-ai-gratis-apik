# Rancangan Desain Kamera AI Gratis

## Arah Produk

Kamera AI Gratis adalah aplikasi kamera portrait-first untuk Android yang membantu pengguna mengambil foto lebih terang dan tajam, memilih sudut ultrawide bila perangkat mendukungnya, serta merekam video dengan bantuan stabilisasi perangkat. Pemrosesan dirancang lokal dan tanpa akun, server, atau kredit Manus.

> Catatan kemampuan: kualitas ultrawide, stabilisasi optik, HDR, dan pemrosesan malam tetap bergantung pada sensor, lensa, chipset, dan API kamera perangkat pengguna. Aplikasi mengoptimalkan kontrol yang tersedia, bukan menggantikan keterbatasan perangkat keras.

## Screen List

| Layar | Konten utama | Fungsi |
|---|---|---|
| Kamera | Pratinjau kamera penuh, tombol rana, pilihan Foto/Video, lensa 0.5x/1x, kontrol terang, ketajaman, dan stabilisasi | Mengambil foto atau merekam video dengan kontrol cepat satu tangan |
| Galeri Lokal | Daftar hasil foto/video terbaru dalam grid | Melihat hasil yang tersimpan lokal dan membuka pratinjau |
| Pratinjau Media | Media terpilih, metadata mode, tombol simpan/bagikan/hapus | Meninjau hasil setelah pengambilan |
| Pengaturan Kamera | Sakelar auto-enhance, grid, suara rana, kualitas video, dan preferensi penyimpanan | Mengatur pengalaman kamera tanpa akun |
| Bantuan | Penjelasan singkat tentang ultrawide, peningkatan gambar, dan stabilisasi | Menetapkan ekspektasi pengguna secara jelas |

## Primary Content and Functionality

Layar Kamera menjadi titik masuk utama. Bagian atas menampilkan status seperti “Cahaya rendah” atau “Stabilisasi aktif” secara ringkas. Area tengah menampilkan viewfinder dengan overlay grid opsional. Kontrol lensa menampilkan 0.5x hanya jika perangkat menyediakan kamera ultrawide; jika tidak, aplikasi menampilkan pesan bahwa lensa tidak tersedia. Slider kompensasi cahaya dan ketajaman ditempatkan sebagai kontrol bawah yang dapat dijangkau ibu jari. Tombol rana besar berada di area bawah tengah, dengan tombol galeri di kiri dan pergantian kamera di kanan.

Mode Foto menjalankan peningkatan lokal ringan setelah pengambilan: kompensasi exposure, penyesuaian kontras, dan ketajaman terkontrol agar hasil tidak berlebihan. Mode Video mengaktifkan stabilisasi yang tersedia pada API kamera dan memberi indikator saat perekaman berjalan. Proses AI cloud tidak digunakan pada versi awal.

## Key User Flows

### Mengambil foto terang dan tajam

1. Pengguna membuka aplikasi dan memberi izin kamera.
2. Aplikasi memilih lensa utama dan menampilkan status pencahayaan.
3. Pengguna memilih Auto Enhance atau mengatur exposure secara manual.
4. Pengguna menekan tombol rana.
5. Aplikasi menyimpan hasil ke galeri lokal dan membuka pratinjau.
6. Pengguna dapat menyimpan, membagikan, atau menghapus hasil.

### Menggunakan ultrawide

1. Pengguna menekan tombol 0.5x.
2. Aplikasi berpindah ke kamera ultrawide jika tersedia.
3. Aplikasi menampilkan peringatan singkat bahwa kondisi cahaya rendah dapat menurunkan detail.
4. Pengguna mengambil foto seperti biasa.

### Merekam video lebih stabil

1. Pengguna memilih tab Video.
2. Aplikasi mengaktifkan stabilisasi yang didukung perangkat.
3. Pengguna menekan tombol rekam.
4. UI menampilkan durasi dan indikator merah.
5. Pengguna menekan tombol berhenti; video disimpan lokal.

## Color Choices

| Token | Warna | Pemakaian |
|---|---|---|
| Background | `#070A0D` | Latar kamera gelap agar viewfinder dominan |
| Surface | `#151A20` | Panel kontrol dan kartu pengaturan |
| Primary | `#F4B942` | Aksen hangat untuk tombol utama dan exposure |
| Foreground | `#F8FAFC` | Teks utama di atas latar gelap |
| Muted | `#A8B3BF` | Informasi sekunder dan status |
| Success | `#49D17D` | Status stabilisasi atau media tersimpan |
| Warning | `#FF9F43` | Peringatan cahaya rendah atau lensa tidak tersedia |
| Error | `#FF6B6B` | Error izin atau penyimpanan |

Desain menggunakan kontras tinggi, target sentuh besar, label yang jelas, dan kontrol yang tidak memerlukan dua tangan. Interaksi utama memakai umpan balik opacity dan haptic ringan; animasi dijaga singkat agar tidak mengganggu framing.
