import AsyncStorage from "@react-native-async-storage/async-storage";

export type CameraMetric = {
  timestamp: string;
  mediaType: "photo" | "video";
  preset: string;
  aiProfile: string;
  engine: string;
  processingMs: number;
  fileSizeBytes: number | null;
  memory: string;
  temperature: string;
};

const STORAGE_KEY = "kamera-ai-gratis.metrics.v1";

export async function recordCameraMetric(metric: CameraMetric) {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const previous = raw ? (JSON.parse(raw) as CameraMetric[]) : [];
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify([metric, ...previous].slice(0, 100)));
  } catch {
    // Metrik tidak boleh mengganggu penyimpanan foto/video.
  }
}

export async function getCameraMetrics(): Promise<CameraMetric[]> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as CameraMetric[]) : [];
  } catch {
    return [];
  }
}

export async function clearCameraMetrics() {
  await AsyncStorage.removeItem(STORAGE_KEY);
}
