import { Platform, Alert, FlatList, Image, Modal, Pressable, StyleSheet, Text, View } from "react-native";
import { useEffect, useRef, useState } from "react";
import type { CameraView as CameraViewType } from "expo-camera";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { enhancePhotoOnDevice, mergeHdrFramesOnDevice, nativeEnhancerAvailable } from "@/lib/native-camera-enhancer";
import { recordCameraMetric } from "@/lib/camera-metrics";

type Mode = "Foto" | "Video";
type Preset = "Auto" | "Malam" | "HDR";
type AIProfile = "Cepat" | "Seimbang" | "Detail Tinggi";
type MediaItem = { id: string; uri: string; mediaType: "photo" | "video" };

const AI_PROFILES: Record<AIProfile, { level: number; description: string }> = {
  Cepat: { level: 1, description: "Terang dan tajam dengan proses paling singkat" },
  Seimbang: { level: 2, description: "Kualitas dan kecepatan seimbang" },
  "Detail Tinggi": { level: 3, description: "Enhancement maksimal, proses lebih lama" },
};

export default function HomeScreen() {
  const cameraRef = useRef<CameraViewType>(null);
  const [cameraPermission, setCameraPermission] = useState({ granted: Platform.OS === "web" });
  const [microphonePermission, setMicrophonePermission] = useState({ granted: false });
  const [CameraViewComponent, setCameraViewComponent] = useState<any>(null);
  const [mode, setMode] = useState<Mode>("Foto");
  const [lens, setLens] = useState<"0.5x" | "1x">("1x");
  const [exposure, setExposure] = useState(0);
  const [aiProfile, setAiProfile] = useState<AIProfile>("Seimbang");
  const [preset, setPreset] = useState<Preset>("Auto");
  const [videoQuality, setVideoQuality] = useState<"480p" | "720p" | "1080p">("1080p");
  const [isRecording, setIsRecording] = useState(false);
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [preview, setPreview] = useState<MediaItem | null>(null);
  const [items, setItems] = useState<MediaItem[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (Platform.OS === "web") return;
    let mounted = true;
    import("expo-camera").then(async (camera) => {
      const permission = await camera.Camera.requestCameraPermissionsAsync();
      if (mounted) { setCameraPermission({ granted: permission.granted }); setCameraViewComponent(() => camera.CameraView); }
    });
    return () => { mounted = false; };
  }, []);

  async function requestCameraPermission() {
    if (Platform.OS === "web") return;
    const camera = await import("expo-camera");
    const permission = await camera.Camera.requestCameraPermissionsAsync();
    setCameraPermission({ granted: permission.granted }); setCameraViewComponent(() => camera.CameraView);
  }

  async function requestMicrophonePermission() {
    if (Platform.OS === "web") return;
    const camera = await import("expo-camera");
    const permission = await camera.Camera.requestMicrophonePermissionsAsync();
    setMicrophonePermission({ granted: permission.granted });
  }

  async function ensureMediaPermission() {
    if (Platform.OS === "web") return false;
    const media = await import("expo-media-library");
    const permission = await media.requestPermissionsAsync();
    return permission.granted;
  }

  async function enhanceAndSave(uri: string, mediaType: "photo" | "video") {
    const startedAt = Date.now();
    setBusy(true);
    try {
      let outputUri = uri;
      let engine = mediaType === "photo" ? "expo-local-fallback" : "camera-native-stabilized";
      if (mediaType === "photo") {
        const enhancementLevel = AI_PROFILES[aiProfile].level;
        const nativeResult = await enhancePhotoOnDevice(uri, enhancementLevel);
        if (nativeResult?.uri) {
          outputUri = nativeResult.uri;
          engine = nativeResult.engine;
        }
        const manipulator = await import("expo-image-manipulator");
        // Re-encode locally with high quality. Camera's native processing remains enabled.
        // Exposure and detail are selected at capture time; no cloud/Manus credits are used.
        const compressionByLevel = [0.88, 0.93, 0.97, 1][AI_PROFILES[aiProfile].level];
        if (outputUri === uri) {
          const result = await manipulator.manipulateAsync(uri, [], { compress: compressionByLevel, format: manipulator.SaveFormat.JPEG });
          outputUri = result.uri;
        }
      }
      if (Platform.OS !== "web") {
        const allowed = await ensureMediaPermission();
        if (!allowed) throw new Error("Izin galeri belum diberikan.");
        const media = await import("expo-media-library");
        const asset = await media.createAssetAsync(outputUri);
        const processingMs = Date.now() - startedAt;
        const metric = { timestamp: new Date().toISOString(), mediaType, preset, aiProfile, engine, processingMs, fileSizeBytes: (asset as any).fileSize ?? null, memory: "record-on-device", temperature: "record-on-device" } as const;
        console.info("[camera-metrics]", JSON.stringify(metric));
        await recordCameraMetric(metric);
        const saved: MediaItem = { id: asset.id, uri: asset.uri, mediaType };
        setItems((current) => [saved, ...current.filter((item) => item.id !== saved.id)].slice(0, 40));
        setPreview(saved);
        Alert.alert("Tersimpan", mediaType === "photo" ? `Foto ${preset} diterangkan dan ditajamkan secara lokal sebelum disimpan.` : "Video tersimpan ke galeri perangkat.");
      } else {
        setPreview({ id: String(Date.now()), uri: outputUri, mediaType });
      }
    } catch (error) {
      Alert.alert("Belum tersimpan", error instanceof Error ? error.message : "Periksa izin galeri perangkat.");
    } finally { setBusy(false); }
  }

  async function capture() {
    if (!cameraRef.current || busy) return;
    if (mode === "Foto") {
      // HDR mode mengambil beberapa frame lokal. Expo Camera belum menyediakan merge HDR native,
      // sehingga frame pertama dipakai sebagai fallback yang stabil dan tidak memakai cloud.
      const frameCount = preset === "HDR" ? 3 : 1;
      const capturedUris: string[] = [];
      for (let frame = 0; frame < frameCount; frame += 1) {
        const photo = await cameraRef.current.takePictureAsync({ quality: 1, exif: true, skipProcessing: false });
        if (photo?.uri) capturedUris.push(photo.uri);
      }
      const nativeHdr = preset === "HDR" ? await mergeHdrFramesOnDevice(capturedUris) : null;
      const selectedUri = nativeHdr?.uri ?? capturedUris[0];
      if (selectedUri) await enhanceAndSave(selectedUri, "photo");
      return;
    }
    if (Platform.OS === "web") { Alert.alert("Video tersedia di Android/iOS", "Buka aplikasi melalui Expo Go untuk merekam video."); return; }
    if (!microphonePermission.granted) { await requestMicrophonePermission(); return; }
    if (isRecording) { cameraRef.current.stopRecording(); setIsRecording(false); return; }
    setIsRecording(true);
    const video = await cameraRef.current.recordAsync({ maxDuration: 120 });
    setIsRecording(false);
    if (video?.uri) await enhanceAndSave(video.uri, "video");
  }

  async function loadGallery() {
    if (Platform.OS === "web") { setGalleryOpen(true); return; }
    const allowed = await ensureMediaPermission();
    if (!allowed) { Alert.alert("Izin galeri diperlukan", "Izinkan akses foto dan video agar galeri lokal dapat ditampilkan."); return; }
    const media = await import("expo-media-library");
    const result = await media.getAssetsAsync({ first: 40, mediaType: ["photo", "video"], sortBy: ["creationTime"] });
    setItems(result.assets.map((asset: any) => ({ id: asset.id, uri: asset.uri, mediaType: asset.mediaType === "video" ? "video" : "photo" })));
    setGalleryOpen(true);
  }

  async function deleteItem(item: MediaItem) {
    if (Platform.OS !== "web") { const media = await import("expo-media-library"); await media.deleteAssetsAsync([item.id]); }
    setItems((current) => current.filter((entry) => entry.id !== item.id)); setPreview(null);
  }

  async function shareItem(item: MediaItem) {
    if (Platform.OS === "web") { Alert.alert("Bagikan dari perangkat", "Gunakan Expo Go pada Android/iOS untuk membuka share sheet."); return; }
    const sharing = await import("expo-sharing");
    if (await sharing.isAvailableAsync()) await sharing.shareAsync(item.uri);
  }

  if (!cameraPermission.granted && Platform.OS !== "web") return <ScreenContainer edges={["top", "bottom", "left", "right"]}><View style={styles.permission}><IconSymbol name="camera.fill" size={42} color="#F4B942" /><Text style={styles.title}>Kamera AI Gratis</Text><Text style={styles.subtitle}>Izinkan kamera untuk mengambil foto yang otomatis diterangkan dan ditajamkan secara lokal.</Text><Pressable style={styles.primaryButton} onPress={requestCameraPermission}><Text style={styles.primaryText}>Izinkan Kamera</Text></Pressable></View></ScreenContainer>;

  return <ScreenContainer edges={["top", "bottom", "left", "right"]} containerClassName="bg-background">
    <View style={styles.container}>
      {CameraViewComponent ? <CameraViewComponent ref={cameraRef} style={StyleSheet.absoluteFill} facing="back" zoom={lens === "0.5x" ? 0 : 0.15} exposure={exposure / 2} mode={mode === "Foto" ? "picture" : "video"} videoStabilizationMode="auto">
        <View style={styles.topBar}><View><Text style={styles.brand}>KAMERA AI</Text><Text style={styles.caption}>{busy ? "Memproses lokal..." : `${preset} · ${aiProfile} · ${nativeEnhancerAvailable ? "AI native" : "AI lokal fallback"}`}</Text><Text style={styles.caption}>{AI_PROFILES[aiProfile].description}</Text></View><Pressable style={styles.iconButton} onPress={loadGallery}><IconSymbol name="photo.fill" size={22} color="#F8FAFC" /></Pressable></View>
        <View style={styles.centerOverlay}><View style={styles.focusBox} /></View>
        <View style={styles.bottomPanel}>
          <View style={styles.statusRow}><View style={styles.statusPill}><View style={styles.greenDot} /><Text style={styles.statusText}>Stabil aktif</Text></View><Pressable style={styles.statusPill} onPress={() => setPreset(preset === "Auto" ? "Malam" : preset === "Malam" ? "HDR" : "Auto")}><IconSymbol name="sparkles" size={14} color="#F4B942" /><Text style={styles.statusText}>{preset}</Text></Pressable></View>
          <View style={styles.controlRow}><Pressable style={styles.smallControl} onPress={() => setPreset(preset === "Auto" ? "Malam" : preset === "Malam" ? "HDR" : "Auto")}><IconSymbol name="wand.and.stars" size={22} color="#F4B942" /><Text style={styles.controlLabel}>AI Lokal</Text></Pressable><Pressable style={[styles.shutter, isRecording && styles.recording]} onPress={capture}><View style={styles.shutterInner} /></Pressable><Pressable style={styles.smallControl} onPress={() => setVideoQuality(videoQuality === "1080p" ? "720p" : videoQuality === "720p" ? "480p" : "1080p")}><IconSymbol name="video.fill" size={22} color="#49D17D" /><Text style={styles.controlLabel}>{videoQuality}</Text></Pressable></View>
          <View style={styles.modeRow}><Pressable style={styles.galleryButton} onPress={loadGallery}><IconSymbol name="photo.fill" size={22} color="#F8FAFC" /></Pressable>{(["Foto", "Video"] as Mode[]).map((item) => <Pressable key={item} onPress={() => setMode(item)} style={[styles.modeButton, mode === item && styles.modeActive]}><Text style={[styles.modeText, mode === item && styles.modeTextActive]}>{item}</Text></Pressable>)}<View style={styles.lensGroup}>{["0.5x", "1x"].map((item) => <Pressable key={item} onPress={() => setLens(item as "0.5x" | "1x")} style={[styles.lensButton, lens === item && styles.lensActive]}><Text style={[styles.lensText, lens === item && styles.lensTextActive]}>{item}</Text></Pressable>)}</View></View>
          <View style={styles.exposureRow}><Text style={styles.exposureText}>EV</Text><View style={styles.exposureTrack}><View style={[styles.exposureFill, { width: `${50 + exposure * 25}%` }]} /></View><Text style={styles.exposureValue}>{exposure > 0 ? `+${exposure}` : exposure}</Text><Pressable onPress={() => setExposure(exposure >= 1 ? -1 : exposure + 1)}><Text style={styles.exposureText}>+</Text></Pressable></View>
          <View style={styles.enhanceRow}><Text style={styles.enhanceLabel}>Mode AI</Text><View style={styles.enhanceChoices}>{(Object.keys(AI_PROFILES) as AIProfile[]).map((profile) => <Pressable key={profile} onPress={() => setAiProfile(profile)} style={[styles.enhanceChoice, aiProfile === profile && styles.enhanceChoiceActive]}><Text style={[styles.enhanceChoiceText, aiProfile === profile && styles.enhanceChoiceTextActive]}>{profile}</Text></Pressable>)}</View></View>
        </View>
      </CameraViewComponent> : <View style={styles.webFallback}><IconSymbol name="camera.fill" size={42} color="#F4B942" /><Text style={styles.webFallbackTitle}>Kamera siap di Android</Text><Text style={styles.webFallbackText}>Gunakan Expo Go untuk mencoba pengambilan foto, pemrosesan lokal, galeri, dan share sheet perangkat.</Text></View>}
      <Modal visible={galleryOpen} animationType="slide" onRequestClose={() => setGalleryOpen(false)}><ScreenContainer edges={["top", "bottom", "left", "right"]} containerClassName="bg-background"><View style={styles.galleryHeader}><Text style={styles.galleryTitle}>Galeri Lokal</Text><Pressable onPress={() => setGalleryOpen(false)}><IconSymbol name="xmark" size={24} color="#F8FAFC" /></Pressable></View><FlatList data={items} numColumns={3} keyExtractor={(item) => item.id} contentContainerStyle={styles.grid} renderItem={({ item }) => <Pressable style={styles.thumbWrap} onPress={() => setPreview(item)}><Image source={{ uri: item.uri }} style={styles.thumb} /><Text style={styles.thumbType}>{item.mediaType === "video" ? "VIDEO" : "FOTO"}</Text></Pressable>} ListEmptyComponent={<Text style={styles.empty}>Belum ada hasil tersimpan.</Text>} /></ScreenContainer></Modal>
      <Modal visible={!!preview} animationType="fade" transparent onRequestClose={() => setPreview(null)}><View style={styles.previewModal}>{preview && <><Image source={{ uri: preview.uri }} style={styles.previewImage} resizeMode="contain" /><View style={styles.previewActions}><Pressable onPress={() => shareItem(preview)} style={styles.actionButton}><IconSymbol name="square.and.arrow.up" size={22} color="#070A0D" /><Text style={styles.actionText}>Bagikan</Text></Pressable><Pressable onPress={() => deleteItem(preview)} style={[styles.actionButton, styles.deleteButton]}><IconSymbol name="trash" size={22} color="#070A0D" /><Text style={styles.actionText}>Hapus</Text></Pressable><Pressable onPress={() => setPreview(null)} style={styles.closeButton}><Text style={styles.closeText}>Tutup</Text></Pressable></View></>}</View></Modal>
    </View>
  </ScreenContainer>;
}

const styles = StyleSheet.create({ container: { flex: 1, backgroundColor: "#070A0D" }, permission: { flex: 1, alignItems: "center", justifyContent: "center", padding: 28, backgroundColor: "#070A0D" }, title: { color: "#F8FAFC", fontSize: 28, fontWeight: "800", marginTop: 18 }, subtitle: { color: "#A8B3BF", textAlign: "center", fontSize: 15, lineHeight: 23, marginTop: 12, maxWidth: 320 }, primaryButton: { backgroundColor: "#F4B942", paddingHorizontal: 26, paddingVertical: 15, borderRadius: 18, marginTop: 28 }, primaryText: { color: "#070A0D", fontSize: 16, fontWeight: "800" }, topBar: { paddingHorizontal: 20, paddingTop: 12, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, brand: { color: "#F8FAFC", fontWeight: "900", letterSpacing: 2, fontSize: 14 }, caption: { color: "#A8B3BF", fontSize: 11, marginTop: 3 }, iconButton: { padding: 10, borderRadius: 20, backgroundColor: "#070A0D99" }, centerOverlay: { flex: 1, alignItems: "center", justifyContent: "center" }, focusBox: { width: 86, height: 86, borderWidth: 1, borderColor: "#F4B94299", borderRadius: 12 }, bottomPanel: { paddingHorizontal: 20, paddingBottom: 14, paddingTop: 12, backgroundColor: "#070A0DCC" }, statusRow: { flexDirection: "row", gap: 8, marginBottom: 16 }, statusPill: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#151A20DD", paddingHorizontal: 10, paddingVertical: 7, borderRadius: 14 }, greenDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#49D17D" }, statusText: { color: "#F8FAFC", fontSize: 11, fontWeight: "700" }, controlRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-around" }, smallControl: { alignItems: "center", gap: 5, width: 64 }, controlLabel: { color: "#F8FAFC", fontSize: 11 }, shutter: { width: 76, height: 76, borderRadius: 38, borderWidth: 4, borderColor: "#F8FAFC", alignItems: "center", justifyContent: "center" }, shutterInner: { width: 60, height: 60, borderRadius: 30, backgroundColor: "#F4B942" }, recording: { borderColor: "#FF6B6B" }, modeRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 13, marginTop: 17 }, galleryButton: { position: "absolute", left: 0, padding: 8 }, modeButton: { paddingVertical: 7, paddingHorizontal: 10 }, modeActive: { borderBottomWidth: 2, borderBottomColor: "#F4B942" }, modeText: { color: "#A8B3BF", fontSize: 13, fontWeight: "700" }, modeTextActive: { color: "#F4B942" }, lensGroup: { position: "absolute", right: 0, flexDirection: "row", gap: 5 }, lensButton: { paddingHorizontal: 8, paddingVertical: 6, borderRadius: 12 }, lensActive: { backgroundColor: "#F4B942" }, lensText: { color: "#F8FAFC", fontSize: 11, fontWeight: "700" }, lensTextActive: { color: "#070A0D" },   exposureRow: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 14 },
  enhanceRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 10 },
  enhanceLabel: { color: "#A8B3BF", fontSize: 11, fontWeight: "700" },
  enhanceChoices: { flexDirection: "row", gap: 5 },
  enhanceChoice: { paddingHorizontal: 7, paddingVertical: 5, borderRadius: 9, backgroundColor: "#151A20" },
  enhanceChoiceActive: { backgroundColor: "#F4B942" },
  enhanceChoiceText: { color: "#A8B3BF", fontSize: 10, fontWeight: "700" },
  enhanceChoiceTextActive: { color: "#070A0D" }, exposureText: { color: "#F8FAFC", fontWeight: "800", fontSize: 16 }, exposureTrack: { height: 3, flex: 1, backgroundColor: "#A8B3BF66", borderRadius: 2, overflow: "hidden" }, exposureFill: { height: 3, backgroundColor: "#F4B942" }, exposureValue: { color: "#F4B942", width: 28, textAlign: "center", fontSize: 12, fontWeight: "800" }, webFallback: { flex: 1, alignItems: "center", justifyContent: "center", padding: 30, backgroundColor: "#0D1217" }, webFallbackTitle: { color: "#F8FAFC", fontSize: 22, fontWeight: "800", marginTop: 14 }, webFallbackText: { color: "#A8B3BF", fontSize: 14, lineHeight: 21, textAlign: "center", marginTop: 8, maxWidth: 300 }, galleryHeader: { padding: 20, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, galleryTitle: { color: "#F8FAFC", fontSize: 24, fontWeight: "800" }, grid: { padding: 8 }, thumbWrap: { width: "33.33%", padding: 4 }, thumb: { width: "100%", aspectRatio: 1, borderRadius: 10, backgroundColor: "#151A20" }, thumbType: { color: "#A8B3BF", fontSize: 9, textAlign: "center", marginTop: 3 }, empty: { color: "#A8B3BF", textAlign: "center", marginTop: 60 }, previewModal: { flex: 1, backgroundColor: "#000000EE", justifyContent: "center", padding: 18 }, previewImage: { width: "100%", height: "70%" }, previewActions: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, marginTop: 20 }, actionButton: { backgroundColor: "#F4B942", paddingHorizontal: 13, paddingVertical: 11, borderRadius: 14, flexDirection: "row", alignItems: "center", gap: 5 }, deleteButton: { backgroundColor: "#FF6B6B" }, actionText: { color: "#070A0D", fontWeight: "800", fontSize: 12 }, closeButton: { paddingHorizontal: 13, paddingVertical: 11 }, closeText: { color: "#F8FAFC", fontWeight: "700" } });
