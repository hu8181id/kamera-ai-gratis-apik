# Kompatibilitas Kamera

Aplikasi menggunakan Expo Camera dan kemampuan native perangkat. Lensa 0.5x hanya bekerja bila perangkat mengekspos kamera ultrawide; pada perangkat tanpa ultrawide, tampilan akan menggunakan kamera utama atau zoom terendah yang tersedia. Stabilisasi video juga mengikuti dukungan hardware dan sistem operasi.

Preset HDR mengambil tiga frame lokal ketika mode HDR dipilih. Pada versi Expo saat ini, frame belum digabungkan oleh pipeline Camera2 native, sehingga frame pertama digunakan sebagai fallback stabil. Penggabungan HDR sungguhan memerlukan modul native Android Camera2 atau model on-device khusus.

Pilihan Enhance mengatur intensitas pipeline lokal dan kualitas re-encode. Untuk peningkatan terang dan ketajaman berbasis model AI yang lebih kuat, diperlukan model TensorFlow Lite/Core ML yang dibundel ke aplikasi dan pengujian performa pada perangkat rendah, menengah, dan tinggi.

Pengujian statis yang berhasil: TypeScript (`pnpm check`) dan lint Expo (`pnpm lint`). Pengujian kamera fisik perlu dilakukan melalui Expo Go atau build Android pada beberapa perangkat dengan kamera ultrawide dan tanpa ultrawide.
