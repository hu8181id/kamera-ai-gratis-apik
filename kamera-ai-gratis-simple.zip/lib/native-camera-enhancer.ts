import { NativeModules, Platform } from "react-native";

export type NativeEnhancementResult = {
  uri: string;
  engine: "esrgan-tflite" | "camera2-native" | "camera2-litert" | "web-fallback";
};

type NativeCameraEnhancer = {
  enhancePhoto?: (uri: string, intensity: number) => Promise<NativeEnhancementResult>;
  mergeHdrFrames?: (uris: string[]) => Promise<NativeEnhancementResult | null>;
};

const nativeModule = Platform.OS === "android"
  ? (NativeModules.ExpoCameraEnhancer as NativeCameraEnhancer | undefined)
  : undefined;

export const nativeEnhancerAvailable = Boolean(nativeModule?.enhancePhoto);

export async function enhancePhotoOnDevice(uri: string, intensity: number): Promise<NativeEnhancementResult | null> {
  if (!nativeModule?.enhancePhoto) return null;
  return nativeModule.enhancePhoto(uri, intensity);
}

export async function mergeHdrFramesOnDevice(uris: string[]): Promise<NativeEnhancementResult | null> {
  if (!nativeModule?.mergeHdrFrames || uris.length < 2) return null;
  return nativeModule.mergeHdrFrames(uris);
}
